<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        //$this->loadComponent('Csrf');
        $this->loadComponent('Paginator');
        $this->loadComponent('Flash'); // Include the FlashComponent
        
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function login()
    {
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                return $this->redirect($this->Auth->redirectUrl());
                $this->Flash->success('You are logged in');
            }
            $this->Flash->error('Your username or password is wrong.');
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Roles', 'Branches']
        ];
        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => ['Roles', 'Branches', 'Accounts']
        ]);

        $this->set('user', $user);
    }


    public function co($branchid = null)
    {
        $user = $this->Users->find();
        
        $branch = $this->loadModel('Branches')->get($branchid);  
        
        $creditofficers =  $this->Users->find()
                ->where(['branch_id' => $branchid])
                ->where(['role_id' => 4]);
        
        $this->set('branchid',$branchid);
        $this->set('branch',$branch);
        
        /* credit officer details */
        $user = $this->Users->get($this->Auth->User('id'));
        $this->set('toid',$user->role_id);  
        //$this->request->allowMethod('ajax');               
        //if the person logging in is a staff

        if($user->role_id == 1)
       {
                //THIS IS THE ADMIN
                //$u_count = $this->Users->find()->->where(['role_id != 1'])->count();
                //$accounts = $this->loadModel('Accounts')->find()
                //->where(['branch_id' => $branchid]);;

                //get total credit and debit
                $query = $this->loadModel('Branches')->get($branchid);   
                $users = $this->Users->find()
                ->where(['branch_id' => $branchid]);                

                $admin = 'admin';
                $co = 'co';
                $this->set('admin',$admin);
                $this->set('co',$co);
                $this->set('branch',$query);             
        }

        $this->set('creditofficers',$creditofficers);
        //$this->set('count',$accounts->count());
        $this->set('user',$user); 
        $this->set('branchId',$branch);  
    }


    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The {0} has been saved.', 'User'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'User'));
        }
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $branches = $this->Users->Branches->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles', 'branches'));
    }


    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The {0} has been saved.', 'User'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'User'));
        }
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $branches = $this->Users->Branches->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles', 'branches'));
    }


    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The {0} has been deleted.', 'User'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'User'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function logout()
{
    $this->Flash->success('You are now logged out.');
    return $this->redirect($this->Auth->logout());
}
}
