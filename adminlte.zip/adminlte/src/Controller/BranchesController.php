<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Branches Controller
 *
 * @property \App\Model\Table\BranchesTable $Branches
 *
 * @method \App\Model\Entity\Branch[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class BranchesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $user = $this->Branches->Users->get($this->Auth->User('id'));
        $this->loadModel('Users');

        //if the person logging in is a staff
        if($user->role_id != 1 && $user->role_id !=5)        {
            $branches = $this->Branches->find()
            ->where(['Branches.id' => $user->branch_id]);
        }
        else if($user->role_id == 1 || $user->role_id == 5 ){
                //THIS IS THE ADMINs
                $u_count = $this->Users->find()->count();
                $accountsc = $this->loadModel('Accounts')->find();

                $db = $accountsc->sumOf('debit');
                $cr = $accountsc->sumOf('credit');
                $bal = $accountsc->sumOf('balance');    
                
                $c_count = $accountsc->count();
                
                $admin = 'admin';
                $dash = 'dash';
                $this->set('admin',$dash);
                $this->set('dash','dash');
                $this->set('c_count',$c_count);
                $this->set('u_count',$u_count);

                $this->set('debit',$db);
                $this->set('credit',$cr);
                $this->set('balance',$bal);  

                //$u_count = $this->Users->find()->->where(['role_id != 1'])->count();
                $branches = $this->loadModel('Branches')->find();
        } 
        
        $this->paginate = [
            'contain' => ['Managers', 'Cashiers', 'Companies']
        ];

        $branches = $this->paginate($this->Branches);

        $this->set('admin', 'sally');
        $this->set('user',$user);

        $this->set(compact('branches'));
    }

    /**
     * View method
     *
     * @param string|null $id Branch id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $branch = $this->Branches->get($id, [
            'contain' => ['Managers', 'Cashiers', 'Companies', 'Accounts', 'Users']
        ]);

        $this->set('branch', $branch);
    }


    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $branch = $this->Branches->newEntity();
        if ($this->request->is('post')) {
            $branch = $this->Branches->patchEntity($branch, $this->request->getData());
            if ($this->Branches->save($branch)) {
                $this->Flash->success(__('The {0} has been saved.', 'Branch'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Branch'));
        }
        $managers = $this->Branches->Managers->find('list', ['limit' => 200]);
        $cashiers = $this->Branches->Cashiers->find('list', ['limit' => 200]);
        $companies = $this->Branches->Companies->find('list', ['limit' => 200]);
        $this->set(compact('branch', 'managers', 'cashiers', 'companies'));
    }


    /**
     * Edit method
     *
     * @param string|null $id Branch id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $branch = $this->Branches->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $branch = $this->Branches->patchEntity($branch, $this->request->getData());
            if ($this->Branches->save($branch)) {
                $this->Flash->success(__('The {0} has been saved.', 'Branch'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Branch'));
        }
        $managers = $this->Branches->Managers->find('list', ['limit' => 200]);
        $cashiers = $this->Branches->Cashiers->find('list', ['limit' => 200]);
        $companies = $this->Branches->Companies->find('list', ['limit' => 200]);
        $this->set(compact('branch', 'managers', 'cashiers', 'companies'));
    }


    /**
     * Delete method
     *
     * @param string|null $id Branch id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $branch = $this->Branches->get($id);
        if ($this->Branches->delete($branch)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Branch'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Branch'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
