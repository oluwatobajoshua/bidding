<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Transaction Entity
 *
 * @property int $id
 * @property int $account_id
 * @property int $credit_officer
 * @property int $bank_teller
 * @property string $ledger_number
 * @property int $reg_year
 * @property int $reg_month
 * @property int $reg_day
 * @property string $state
 * @property float $amount
 * @property string $particular
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 *
 * @property \App\Model\Entity\Account $account
 */
class Transaction extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'account_id' => true,
        'credit_officer' => true,
        'bank_teller' => true,
        'ledger_number' => true,
        'reg_year' => true,
        'reg_month' => true,
        'reg_day' => true,
        'state' => true,
        'amount' => true,
        'particular' => true,
        'created' => true,
        'modified' => true,
        'account' => true
    ];
}
