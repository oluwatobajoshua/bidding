<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Branch Entity
 *
 * @property int $id
 * @property int $manager_id
 * @property int $cashier_id
 * @property int $company_id
 * @property int $users_count
 * @property int $accounts_count
 * @property float $credit
 * @property float $debit
 * @property float $balance
 * @property string $name
 * @property string $address
 * @property \Cake\I18n\FrozenDate $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Manager $manager
 * @property \App\Model\Entity\Cashier $cashier
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\Account[] $accounts
 * @property \App\Model\Entity\User[] $users
 */
class Branch extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'manager_id' => true,
        'cashier_id' => true,
        'company_id' => true,
        'users_count' => true,
        'accounts_count' => true,
        'credit' => true,
        'debit' => true,
        'balance' => true,
        'name' => true,
        'address' => true,
        'created' => true,
        'modified' => true,
        'manager' => true,
        'cashier' => true,
        'company' => true,
        'accounts' => true,
        'users' => true
    ];
}
